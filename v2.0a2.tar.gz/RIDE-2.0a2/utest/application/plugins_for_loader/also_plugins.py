from robotide.pluginapi import Plugin


class ExamplePlugin3(Plugin):

    def __init__(self, application):
        Plugin.__init__(self, application)
