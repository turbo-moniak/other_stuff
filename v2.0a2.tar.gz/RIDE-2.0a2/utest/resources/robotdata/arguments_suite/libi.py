class libi(object):

    def __init__(self, *args):
        pass

    def onething(self):
        pass

