#!/bin/bash
echo "TC 3. Check available memory." >> /test/test_result.txt

MEMORY=$(cat /proc/meminfo | grep MemTotal)
MEMORY=${MEMORY:17:7}
REQUIREDMEM=2000000

if [ "$MEMORY" -ge "$REQUIREDMEM" ]; then
	echo "Pass" >> /test/test_result.txt
else
	echo "Fail" >> /test/test_result.txt
fi

