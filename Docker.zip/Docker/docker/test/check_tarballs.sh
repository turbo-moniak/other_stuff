#!/bin/bash
echo "TC 4. Test tarballs needed to install Robot Framework RIDE." >> /test/test_result.txt

TARBALLS=(v2.0a2.tar.gz wxGTK-2.8.12.tar.gz wxPython-src-2.8.12.1.tar.bz2)
FILES=/home/monika/docker/files/*
COUNTER=0

for tarball in "${TARBALLS[@]}"
do
	for file in $FILES
	do
		echo $file
		echo $tarball

		if [[ $file = *$tarball* ]]; then
			COUNTER=$((COUNTER+1))
			echo $COUNTER
		fi
	done
done

echo $COUNTER

if [ $COUNTER -eq 3 ]; then
	echo "Pass" >> /test/test_result.txt
else
	echo "Fail" >> /test/test_result.txt
fi


