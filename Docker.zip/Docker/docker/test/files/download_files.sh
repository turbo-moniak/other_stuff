#!/bin/bash
wget -q https://github.com/HelioGuilherme66/RIDE/archive/v2.0a2.tar.gz 
wget -q https://github.com/wxWidgets/wxWidgets/releases/download/v2.8.12/wxGTK-2.8.12.tar.gz 
wget -q https://sourceforge.net/projects/wxpython/files/wxPython/2.8.12.1/wxPython-src-2.8.12.1.tar.bz2 
