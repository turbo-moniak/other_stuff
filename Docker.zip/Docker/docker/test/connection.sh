#!/bin/bash
echo "TC 1. Test internet connection." >> /test/test_result.txt

wget --spider --quiet http://google.com
if [ "$?" != 0 ]; then
	echo "Fails" >> /test/test_result.txt
else
	echo "Pass" >> /test/test_result.txt
fi
