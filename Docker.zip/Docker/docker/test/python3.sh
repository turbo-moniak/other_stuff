#!/bin/bash
echo "TC 2. Check if Python3 is installed." >> /test/test_result.txt

python3 -V 2> /dev/null

if [ $? -eq 0 ]; then
	echo "Pass" >> /test/test_result.txt
else
	echo "Fail" >> /test/test_result.txt
fi
