#!/bin/bash
echo "Executing test case 1"
./test/connection.sh
sleep 2
echo "Executing test case 2"
./test/python3.sh
sleep 2
echo "Executing test case 3"
./test/memory.sh


